﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace CommonDAL
{
    public static class IMSERPSeedData
    {
        public static void Seed(this ModelBuilder builder)
        {
            //builder.Entity<Table>().HasData(new Table { })
        }
    }
}
