﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonDAL.ViewModels
{
   public class DistrictViewModel
    {
        public int Id { get; set; }
        public int DivisionId { get; set; }
        public string DistrictName { get; set; }
    }
}
