﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonDAL.ViewModels
{
    public class ForgetPasswordViewModel
    {
        public string Email { get; set; }
        public string Link { get; set; }
    }
}
