﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonDAL.Models
{
    public class IMSSetting
    {
        public string IMSSequrity { get; set; }
        public string IMSHost { get; set; }
    }
}
